# スタジオ空室チェッカー

BUZZ と studio worcle の空き状況をまとめて表示するツールです。
「○時〜○時が続けて空いている部屋」を一覧にします。

## 準備（最初の1回だけ）

```
pip install -r requirements.txt
```

## 使い方

```
python checker.py                              # 今日・config.json の既定の時間帯
python checker.py -d 2026-11-03                # 日付を指定
python checker.py -d 2026-11-03 -n 3           # 11/3から3日分
python checker.py --from 19:00 --to 22:00 --min 2   # 19〜22時に2時間以上続けて空き
python checker.py -s 町田                       # ラベルに「町田」を含む店舗だけ
python checker.py --rooms 401st 501st          # 部屋を絞る
python checker.py --to 30:00                   # 深夜（翌6時）まで含める
```

## 店舗の追加・変更

`config.json` の `stores` に1行足します。`store` は各サイトのURLの店舗部分です。

- BUZZ：`https://buzz-st.com/machida` → `"store": "machida"`
- worcle：`https://www.studioworcle.com/shinjuku/` → `"store": "shinjuku"`

## 新しいサイトの追加

`sites/` に `<サイト名>.py` を作り、`get_slots(store, label, first_day, days)` で
`Slot` のリストを返すようにして、`sites/__init__.py` の `SITES` に登録します。
読み取り部分のテストは `python -m unittest discover tests` で実行できます。

## 仕組みとメモ

- BUZZ：予約表ページに7日分の空き状況（0=空き/1=予約済み）が埋め込まれているのを読んでいます。
- worcle：店舗ページに1か月分の空き状況が `mydata` というJSONで埋め込まれているのを読んでいます。
  最後の枠は深夜パック（24:00〜30:00）です。
- どちらもアクセスは1.5秒以上あけています。定期実行する場合も数十分に1回程度にしてください。
- サイトの作りが変わると「見つかりません」というエラーになります。その場合は読み取り部分の修正が必要です。

---

# LINE通知（監視モード）

`config.json` の `watches` に書いた条件に合う空きが**新しく出たときだけ**、LINEに1通にまとめて通知します。
一度通知した「日付・条件・店舗・部屋」は `state.json` に記録され、埋まって再び空くまでは再通知しません。

## 監視条件の書き方（config.json の watches）

```json
{ "name": "土日の練習", "weekdays": ["土", "日"], "days_ahead": 14,
  "from": "18:00", "to": "22:00", "min_hours": 2,
  "stores": ["BUZZ町田", "BUZZ相模原"] }
```

- 日付は `"dates": ["2026-11-08"]` のように直接指定するか、`weekdays`（曜日）＋ `days_ahead`（今日から何日先まで）で指定
- `stores` は `stores` の `label` で指定（省略すると全店舗）
- `rooms` で部屋を絞れる（省略すると全部屋）

## 1. LINE公式アカウントの準備

1. LINE Official Account Manager でLINE公式アカウントを作成（無料のコミュニケーションプランでOK）
2. アカウントの「設定」→「Messaging API」→「Messaging APIを利用する」
3. LINE Developers コンソールでそのチャネルを開く
   - 「Messaging API設定」タブ → **チャネルアクセストークン（長期）** を発行してコピー
   - 「チャネル基本設定」タブの下の方 → **あなたのユーザーID**（Uから始まる）をコピー
4. 「Messaging API設定」タブのQRコードを読み取って、自分のLINEで友だち追加

## 2. GitHub Actions で30分おきに実行

1. GitHubで **Private** リポジトリを作り、このフォルダの中身を全部アップロード（`.github` フォルダも含む）
2. リポジトリの Settings → Secrets and variables → Actions → New repository secret で2つ登録
   - `LINE_CHANNEL_ACCESS_TOKEN` … 1-3 のトークン
   - `LINE_USER_ID` … 1-3 のユーザーID
3. Actions タブ → 「studio watch」→ 「Run workflow」で手動実行して、LINEに届くか確認
4. 以降は30分おきに自動で動きます（GitHub側の都合で多少遅れることがあります）

iPhoneの GitHub アプリからも Actions の手動実行ができるので、「今すぐ確認したい」ときに使えます。
通知を止めたいときは Actions タブで「Disable workflow」。

## ローカルでの確認

```
python watch.py --dry-run     # 通知せず、送る予定の内容を表示
```
