#include <stdio.h>
#include <GL/glut.h>

static const int WIN_WIDTH  = 256; // window width (pixel)
static const int WIN_HEIGHT = 256; // window height (pixel)

void Initialize();
void Display();

//////////////////////////////////////////////////////////////////////////////////

int main( int argc, char *argv[] ) {
    
    glutInit( &argc, argv ); // init GLUT 
    glutInitWindowSize( WIN_WIDTH, WIN_HEIGHT ); // set window size
    glutInitDisplayMode (GLUT_RGBA | GLUT_DEPTH);  // framebuffer has RGB+A and Depth-buffer
    glutCreateWindow( "OpenGL Matrix" );  // Create OpenGL window
    
    Initialize(); // init GL environment
    glutDisplayFunc( Display );   // set display loop function
 
    // start rendering
    glutMainLoop();

    return 0;
}

//////////////////////////////////////////////////////////////////////////////////

// init
void Initialize() {
    glClearColor( 0.5f, 0.5f, 0.5f, 1.0f ); // set background color: Red,Green,Blue,Alpha

    glEnable(GL_DEPTH_TEST); // enable depth test

    // set projection matrix
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    /**/
    glFrustum( -1.0f, +1.0f,   // xrange -1~+1
	       -1.0f, +1.0f,   // yrange -1~+1
	        1.0f, +100.0f ); // distance range 1~100 (Z=-1.0~-100.0)
    /**/
    /**
    glOrtho( -1.0f, +1.0f,   // xrange -1~+1
	     -1.0f, +1.0f,   // yrange -1~+1
	      1.0f, +100.0f ); // distance range 1~100 (Z=-1.0~-100.0)
    **/

    // set light source information
    glEnable(GL_LIGHTING); // enable lighting 

    GLfloat pLightPos[4]   = { 2.5f, 2.0f, 0.0f, 1.0f }; // light's position (x,y,z,1)
    GLfloat pLightColor[4] = { 1.0f, 1.0f, 1.0f, 1.0f }; // light's color (rgba)

    glEnable(GL_LIGHT0); // enable light source
    glLightfv(GL_LIGHT0, GL_POSITION, pLightPos);  // set light's position
    glLightfv(GL_LIGHT0, GL_DIFFUSE, pLightColor); // set light's color
}
 
// draw
void Display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clear framebuffer and depth-buffer

    // set teapot color
    GLfloat pTeapotColor[] = { 1.0f, 0.7f, 0.7f, 1.0f }; // teapot color (rgba)
    glMaterialfv(GL_FRONT, GL_DIFFUSE, pTeapotColor);

    glMatrixMode(GL_MODELVIEW); // set matrix mode to 3d-transformation

    glLoadIdentity();
    glTranslatef( 0.0f, 0.0f, -5.0f );     // 2. translate
    glRotatef( 30.0f, 0.0f, 1.0f, 0.0f );  // 1. rotate
    /**
    glRotatef( 30.0f, 0.0f, 1.0f, 0.0f );  // 2. rotate
    glTranslatef( 0.0f, 0.0f, -5.0f );     // 1. translate
    **/

    glutSolidTeapot( 1.0f ); // draw teapot

    glFlush(); // end of display routine
}

/////////////////////////
